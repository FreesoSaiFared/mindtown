# Next action

Build Turn 4 through the inverse-agent gate: render Oren as a second voxel inhabitant and run independently scheduled local mind turns for Mira and Oren.

Each character must receive its own perception, update only its own action state, preserve separate social memory, and replay the interleaved event stream deterministically in Chromium.
