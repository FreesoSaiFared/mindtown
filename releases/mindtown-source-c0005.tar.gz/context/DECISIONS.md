# Decisions

- PlayCanvas Engine is the permanent runtime foundation.
- The local Town Workbench is built into the same application and scene model as runtime mode.
- Handoffs use one complete full checkpoint plus one cumulative Git-bundle delta.
- Context files are committed so the session can be resumed without reconstructing intent from chat history.
- Agent patches are path-scoped and tested before commit.
