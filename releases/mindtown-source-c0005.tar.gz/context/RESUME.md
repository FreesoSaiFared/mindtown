# Resume MindTown development

Read in this order:

1. `context/CURRENT_STATE.md`
2. `context/NEXT_ACTION.md`
3. `context/DECISIONS.md`
4. `docs/INVERSE_SESSION_WORKFLOW.md`
5. the newest unresolved file under `agent/requests/`

Validate the checkout:

```bash
cd /opt/dev/work/mindtown
git status --short
git log --oneline -8
./tools/test.sh
```

Browser proof:

```bash
./tools/test_browser.sh
```

Create a bounded inverse-agent request:

```bash
python3 tools/sessionctl.py request \
  --task "describe one concrete change" \
  --scope 'src/**' --scope 'test/**' \
  --test './tools/test.sh'
```

After writing the response patch under `agent/responses/`, apply it through the VM:

```bash
python3 tools/sessionctl.py apply --request REQUEST_ID \
  --patch agent/responses/REQUEST_ID.patch \
  --response agent/responses/REQUEST_ID-response.md
```

Emit a resumable checkpoint:

```bash
python3 tools/sessionctl.py checkpoint --message "checkpoint description" --browser
```
