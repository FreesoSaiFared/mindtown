# Project map

## .gitignore
- `.gitignore`

## .mindtown
- `.mindtown/journal.jsonl`
- `.mindtown/session.json`

## 00_AI_START_HERE__REPORT_STATE_AND_RUN_RESUME.md
- `00_AI_START_HERE__REPORT_STATE_AND_RUN_RESUME.md`

## 01_AI_DO_THIS_NOW__RUN_SINGLE_RESUME_COMMAND.md
- `01_AI_DO_THIS_NOW__RUN_SINGLE_RESUME_COMMAND.md`

## 02_AI_CONTINUE_DEVELOPMENT__READ_NEXT_ACTION_AND_CREATE_REQUEST.md
- `02_AI_CONTINUE_DEVELOPMENT__READ_NEXT_ACTION_AND_CREATE_REQUEST.md`

## 03_USER_ACTION_REQUIRED__ONE_THING_ONLY.md
- `03_USER_ACTION_REQUIRED__ONE_THING_ONLY.md`

## README.md
- `README.md`

## agent
- `agent/requests/.gitkeep`
- `agent/requests/S001-R0001-request.json`
- `agent/requests/S001-R0001-request.md`
- `agent/requests/S001-R0002-request.json`
- `agent/requests/S001-R0002-request.md`
- `agent/requests/S001-R0003-request.json`
- `agent/requests/S001-R0003-request.md`
- `agent/requests/S001-R0004-request.json`
- `agent/requests/S001-R0004-request.md`
- `agent/requests/S001-R0005-request.json`
- `agent/requests/S001-R0005-request.md`
- `agent/requests/S001-R0006-request.json`
- `agent/requests/S001-R0006-request.md`
- `agent/requests/S001-R0007-request.json`
- `agent/requests/S001-R0007-request.md`
- `agent/responses/.gitkeep`
- `agent/responses/S001-R0001-response.md`
- `agent/responses/S001-R0001.patch`
- `agent/responses/S001-R0002-response.md`
- `agent/responses/S001-R0002.patch`
- `agent/responses/S001-R0003-response.md`
- `agent/responses/S001-R0003.patch`
- `agent/responses/S001-R0004-response.md`
- `agent/responses/S001-R0004.patch`
- `agent/responses/S001-R0005-response.md`
- `agent/responses/S001-R0005.patch`
- `agent/responses/S001-R0006-response.md`
- `agent/responses/S001-R0006.patch`
- `agent/responses/S001-R0007-response.md`
- `agent/responses/S001-R0007.patch`
- `agent/results/.gitkeep`
- `agent/results/S001-R0001-result.json`
- `agent/results/S001-R0002-result.json`
- `agent/results/S001-R0003-result.json`
- `agent/results/S001-R0004-result.json`
- `agent/results/S001-R0005-result.json`
- `agent/results/S001-R0006-result.json`
- `agent/results/S001-R0007-result.json`

## context
- `context/CURRENT_STATE.md`
- `context/DECISIONS.md`
- `context/NEXT_ACTION.md`
- `context/PROJECT_MAP.md`
- `context/RECOVERY_PROOF.json`
- `context/RESUME.md`
- `context/TEST_STATUS.json`

## docs
- `docs/HANDOFF_RECOVERY_PROOF.md`
- `docs/INVERSE_SESSION_WORKFLOW.md`
- `docs/MINDTOWN_OPERATIONAL_PROPOSAL.md`
- `docs/MINDTOWN_REPOSITORY_QUALIFICATION.md`
- `docs/PROJECT_CONTINUITY_AND_CALENDAR_WORKFLOW.md`
- `docs/PROJECT_MAXIMUM_TIMELINE.md`
- `docs/SESSION_001_IMPLEMENTATION_LOG.md`
- `docs/TURN_3_WORLD_REACTIONS_AND_SOCIAL_MEMORY.md`
- `docs/VM_MASTER_GUIDE_UPDATE_2026-08-05.md`

## package.json
- `package.json`

## public
- `public/app.js`
- `public/data/default-scene.json`
- `public/index.html`
- `public/mind-runtime.mjs`
- `public/scene-state.mjs`
- `public/styles.css`
- `public/vendor/playcanvas.mjs`

## resume-mindtown.sh
- `resume-mindtown.sh`

## server.mjs
- `server.mjs`

## test
- `test/actionable-workflow.test.mjs`
- `test/browser_turn1.py`
- `test/handoff-clean.test.mjs`
- `test/mind-runtime.test.mjs`
- `test/scene-state.test.mjs`

## tools
- `tools/__pycache__/sessionctl.cpython-313.pyc`
- `tools/recovery_probe.py`
- `tools/resume_handoff.py`
- `tools/sessionctl.py`
- `tools/start.sh`
- `tools/test.sh`
- `tools/test_browser.sh`
- `tools/validate_project.py`
