# MindTown

MindTown is a PlayCanvas town whose inhabitants can later use separate browser conversations as minds. The current vertical slice provides the town, local workbench, persistent scene data, deterministic local minds, world reactions, bounded social memory, replay, and resumable inverse-session handoffs.

## Run

```bash
./tools/start.sh
```

Open `http://127.0.0.1:8788/`.

## Test

```bash
./tools/test.sh
./tools/test_browser.sh
```

## Resume a new ChatGPT VM session

Read `context/RESUME.md`. A full handoff plus the newest cumulative delta is sufficient.

## Town controls

Runtime mode: click the ground to move Mira.

Workbench mode: choose an object type and click the ground to place it; select an existing object to rename, recolor, move or delete it. Save writes `MINDTOWN_SCENE/1` to browser local storage. Reload proves persistence.

## Plain-English continuation

The user resumes the project by saying:

```text
Resume MindTown from Google Drive.
```

A session that has the checkout runs:

```bash
./resume-mindtown.sh
```

Start with `00_AI_START_HERE__REPORT_STATE_AND_RUN_RESUME.md`. Google Drive is the durable recovery source. The public source repository is `FreesoSaiFared/mindtown`; checkpoints are published there after VM and Chromium verification.
