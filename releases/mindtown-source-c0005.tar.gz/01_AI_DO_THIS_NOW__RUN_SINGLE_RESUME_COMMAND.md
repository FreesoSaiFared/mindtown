# AI: run the single resume command now

From the project directory, run:

```bash
./resume-mindtown.sh
```

Do not replace this with a description of what the command would do. Run it.

The command checks that the Git checkout is coherent, runs the native tests, prints the current phase, prints the next task, and states whether human attention is required.
