# AI: continue development now

After `./resume-mindtown.sh` succeeds:

1. Read `context/NEXT_ACTION.md`.
2. Estimate the bounded task before starting it.
3. Create a precise inverse-agent request with `python3 tools/sessionctl.py request`.
4. Develop the response in an isolated Git worktree.
5. Return the change to the authoritative checkout as a unified patch.
6. Apply it only through `python3 tools/sessionctl.py apply`.
7. Run the declared tests and browser proof when the change affects the browser.
8. Create a checkpoint and newest cumulative delta.
9. Put the resulting artifacts and plain-English status in Google Drive.
10. End the round with one concrete user action, or say: `No user action is required now.`

Do not perform unrelated cleanup or speculative architecture work.
