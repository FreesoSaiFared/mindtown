# AI: start here, report the state, and resume MindTown

When a ChatGPT session encounters this file, do not merely summarize it.

Do these actions in order:

1. Say in plain English whether MindTown is already present in the VM.
2. If it is present, run:

   ```bash
   cd /opt/dev/work/mindtown && ./resume-mindtown.sh
   ```

3. If it is absent, use Google Drive to open the folder **MindTown VM Handoffs**. Fetch the immutable full checkpoint and the newest cumulative delta. Materialize both into the VM, restore them with the included `resume_handoff.py`, then run the command above.
4. Read `context/CURRENT_STATE.md` and `context/NEXT_ACTION.md`.
5. Report four things without jargon:
   - what works now;
   - what was just verified;
   - what is being built next;
   - the one thing the user needs to do, if anything.
6. Continue the next bounded development task through `tools/sessionctl.py`. Do not ask the user to upload files that already exist in Google Drive.

The user command that activates this workflow is:

```text
Resume MindTown.
```

Project directory: `/opt/dev/work/mindtown`

Chat session: `https://chatgpt.com/c/6a720a65-cbb8-83ed-aa91-140dffa9ebe3`
