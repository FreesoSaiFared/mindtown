# Handoff recovery proof

Checkpoint `C0001` was emitted as an immutable full handoff and restored into a blank directory without using the original working tree or conversation history.

Observed proof:

- ZIP integrity test passed.
- `resume_handoff.py init` cloned the bundled Git repository.
- Restored HEAD matched `8a453f1458c29729f3296d9077f92bb4b32739d0`.
- Restored worktree contained 38 tracked files and was clean.
- All six scene-state tests passed.
- Static project validation passed.

Future sessions can repeat the proof with:

```bash
python3 tools/recovery_probe.py \
  --full /mnt/data/MINDTOWN_FULL_S001_C0001_8a453f1458.zip
```

Once a cumulative delta exists:

```bash
python3 tools/recovery_probe.py \
  --full /mnt/data/MINDTOWN_FULL_S001_C0001_8a453f1458.zip \
  --delta /mnt/data/MINDTOWN_DELTA_FROM_FULL_C0002_<commit>.zip
```

The probe extracts into a temporary directory, verifies the handoff checksums through the bundled resume program, restores the full repository, applies the optional delta, runs the restored test suite, checks the exact target commit, and requires a clean worktree.
