# Inverse VM Session Workflow

The VM owns the repository, tests, Git history, browser evidence, checkpoints and rollback. The surrounding ChatGPT session supplies bounded reasoning and patches through files.

## Loop

1. `sessionctl.py request` writes a bounded request under `agent/requests/`.
2. The chat session reads the request and writes a response note plus unified patch under `agent/responses/`.
3. `sessionctl.py apply` verifies path scope, runs `git apply --check`, applies the patch, runs the declared test, writes the result and commits only on success.
4. `sessionctl.py checkpoint` refreshes context and emits a cumulative delta ZIP.
5. At major boundaries, `sessionctl.py handoff full` emits a new immutable full ZIP and resets the delta base.

## Recovery objects

A full handoff contains a source snapshot, a complete Git bundle, context files, tests and a standalone resume program. A cumulative delta contains all commits after the full handoff base. Therefore a new browser window needs exactly:

- the latest full ZIP;
- the latest cumulative delta ZIP, when one exists.

Incremental deltas are optional diagnostics, not required for recovery.
